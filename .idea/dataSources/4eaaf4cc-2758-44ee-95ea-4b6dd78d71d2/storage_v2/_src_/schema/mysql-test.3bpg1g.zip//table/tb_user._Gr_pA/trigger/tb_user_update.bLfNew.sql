create definer = root@localhost trigger tb_user_update
    after update
    on tb_user
    for each row
begin
    insert into user_logs values (null,'update',now(),OLD.id,concat('更新之前的内容为:id = ',OLD.id,'，name = ', OLD.name, ',address = ', OLD.workaddress,
        '  |  更新之后的内容为:id = ',new.id,'，name = ', new.name, ',address = ', new.workaddress));
end;

