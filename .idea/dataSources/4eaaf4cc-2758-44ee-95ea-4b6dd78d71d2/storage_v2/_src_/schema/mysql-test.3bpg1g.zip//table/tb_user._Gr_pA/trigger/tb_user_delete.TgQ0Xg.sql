create definer = root@localhost trigger tb_user_delete
    after delete
    on tb_user
    for each row
begin
    insert into user_logs values (null,'delete',now(),OLD.id,concat('删除 之前的内容为:id = ',OLD.id,'，name = ', OLD.name, ',address = ', OLD.workaddress));
end;

