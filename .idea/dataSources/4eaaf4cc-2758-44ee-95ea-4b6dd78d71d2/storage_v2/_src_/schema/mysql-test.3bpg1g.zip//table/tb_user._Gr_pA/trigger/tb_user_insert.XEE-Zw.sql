create definer = root@localhost trigger tb_user_insert
    after insert
    on tb_user
    for each row
begin
    insert into user_logs values (null,'insert',now(),new.id,concat('插入的内容为:id = ',new.id,'，name = ', new.name, ',address = ', new.workaddress));
end;

