create definer = `mariadb.sys`@localhost view x$session as
select `x$processlist`.`thd_id`                 AS `thd_id`,
       `x$processlist`.`conn_id`                AS `conn_id`,
       `x$processlist`.`user`                   AS `user`,
       `x$processlist`.`db`                     AS `db`,
       `x$processlist`.`command`                AS `command`,
       `x$processlist`.`state`                  AS `state`,
       `x$processlist`.`time`                   AS `time`,
       `x$processlist`.`current_statement`      AS `current_statement`,
       `x$processlist`.`statement_latency`      AS `statement_latency`,
       `x$processlist`.`progress`               AS `progress`,
       `x$processlist`.`lock_latency`           AS `lock_latency`,
       `x$processlist`.`rows_examined`          AS `rows_examined`,
       `x$processlist`.`rows_sent`              AS `rows_sent`,
       `x$processlist`.`rows_affected`          AS `rows_affected`,
       `x$processlist`.`tmp_tables`             AS `tmp_tables`,
       `x$processlist`.`tmp_disk_tables`        AS `tmp_disk_tables`,
       `x$processlist`.`full_scan`              AS `full_scan`,
       `x$processlist`.`last_statement`         AS `last_statement`,
       `x$processlist`.`last_statement_latency` AS `last_statement_latency`,
       `x$processlist`.`current_memory`         AS `current_memory`,
       `x$processlist`.`last_wait`              AS `last_wait`,
       `x$processlist`.`last_wait_latency`      AS `last_wait_latency`,
       `x$processlist`.`source`                 AS `source`,
       `x$processlist`.`trx_latency`            AS `trx_latency`,
       `x$processlist`.`trx_state`              AS `trx_state`,
       `x$processlist`.`trx_autocommit`         AS `trx_autocommit`,
       `x$processlist`.`pid`                    AS `pid`,
       `x$processlist`.`program_name`           AS `program_name`
from `sys`.`x$processlist`
where `x$processlist`.`conn_id` is not null
  and `x$processlist`.`command` <> 'Daemon';

-- comment on column x$session.thd_id not supported: A unique thread identifier.

-- comment on column x$session.conn_id not supported: The PROCESSLIST.ID value for threads displayed in the INFORMATION_SCHEMA.PROCESSLIST table, or 0 for background threads. Also corresponds with the CONNECTION_ID() return value for the thread.

-- comment on column x$session.db not supported: Thread's default database, or NULL if none exists.

-- comment on column x$session.command not supported: Type of command executed by the thread. These correspond to the the COM_xxx client/server protocol commands, and the Com_xxx status variables. See Thread Command Values.

-- comment on column x$session.state not supported: Action, event or state indicating what the thread is doing.

-- comment on column x$session.time not supported: Time in seconds the thread has been in its current state.

-- comment on column x$session.current_statement not supported: Statement being executed by the thread, or NULL if a statement is not being executed. If a statement results in calling other statements, such as for a stored procedure, the innermost statement from the stored procedure is shown here.

-- comment on column x$session.lock_latency not supported: Time in picoseconds spent waiting for locks. The time is calculated in microseconds but stored in picoseconds for compatibility with other timings.

-- comment on column x$session.rows_examined not supported: Number of rows read during the statement's execution.

-- comment on column x$session.rows_sent not supported: Number of rows returned.

-- comment on column x$session.rows_affected not supported: Number of rows affected the statement affected.

-- comment on column x$session.tmp_tables not supported: Number of temp tables created by the statement.

-- comment on column x$session.tmp_disk_tables not supported: Number of on-disk temp tables created by the statement.

-- comment on column x$session.last_wait not supported: Event instrument name and a NAME from the setup_instruments table

-- comment on column x$session.source not supported: Name and line number of the source file containing the instrumented code that produced the event.

-- comment on column x$session.trx_latency not supported: The unit is picoseconds. Event duration. NULL if event has not timing information.

-- comment on column x$session.trx_state not supported: The current transaction state. The value is ACTIVE (after START TRANSACTION or BEGIN), COMMITTED (after COMMIT), or ROLLED BACK (after ROLLBACK).

-- comment on column x$session.trx_autocommit not supported: Whether autcommit mode was enabled when the transaction started.

-- comment on column x$session.pid not supported: Attribute value.

-- comment on column x$session.program_name not supported: Attribute value.

